import React, { useState } from 'react';
import { Match, SportType, Article } from './types/sports';
import { INITIAL_MATCHES, ARTICLES_DATA } from './data/sportsData';
import { Header } from './components/Header';
import { LiveScoresTicker } from './components/LiveScoresTicker';
import { HeroMatchSpotlight } from './components/HeroMatchSpotlight';
import { StandingsTable } from './components/StandingsTable';
import { NewsSection } from './components/NewsSection';
import { FanPredictions } from './components/FanPredictions';
import { TacticalPitch } from './components/TacticalPitch';
import { MatchCenterModal } from './components/MatchCenterModal';
import { ArticleModal } from './components/ArticleModal';
import { SearchModal } from './components/SearchModal';
import { AudioBroadcastPlayer } from './components/AudioBroadcastPlayer';
import { Footer } from './components/Footer';
import { Radio, ArrowUpRight, Flame, Shield, TrendingUp } from 'lucide-react';

export default function App() {
  const [matches, setMatches] = useState<Match[]>(INITIAL_MATCHES);
  const [selectedSport, setSelectedSport] = useState<SportType>('all');
  const [activeTab, setActiveTab] = useState<string>('live');
  const [activeMatchForModal, setActiveMatchForModal] = useState<Match | null>(null);
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [isRadioPlaying, setIsRadioPlaying] = useState<boolean>(false);
  const [isRadioOpen, setIsRadioOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);

  // Marquee match is the first football match (Arsenal vs Man City)
  const marqueeMatch = matches[0];

  const handleToggleRadio = () => {
    setIsRadioPlaying(prev => !prev);
    setIsRadioOpen(true);
  };

  // Real-time game event simulation
  const handleSimulateAction = () => {
    setMatches(prevMatches => {
      const updated = [...prevMatches];
      const match = { ...updated[0] };
      const currentEvents = [...match.events];

      const currentScoreHome = typeof match.homeTeam.score === 'number' ? match.homeTeam.score : 2;
      const newScore = currentScoreHome + 1;

      currentEvents.push({
        minute: 82,
        type: 'goal',
        player: 'Bukayo Saka',
        team: 'home',
        detail: 'Curling strike into the top corner following quick counter-attack',
      });

      match.homeTeam = {
        ...match.homeTeam,
        score: newScore,
      };
      match.statusText = "82'";
      match.events = currentEvents;
      match.stats = {
        ...match.stats,
        shots: [match.stats.shots[0] + 1, match.stats.shots[1]],
        shotsOnTarget: [match.stats.shotsOnTarget[0] + 1, match.stats.shotsOnTarget[1]],
        possession: [55, 45],
        xG: [match.stats.xG ? +(match.stats.xG[0] + 0.45).toFixed(2) : 2.59, 1.38],
      };
      match.summary = 'GOAL! Bukayo Saka scores his second of the night with a trademark curling strike to make it 3-1 for Arsenal at the Emirates!';

      updated[0] = match;
      return updated;
    });
  };

  const handleSelectTab = (tab: string) => {
    setActiveTab(tab);
    const element = document.getElementById(tab);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-black">
      {/* Header with Top Bar Contract */}
      <Header
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        isRadioPlaying={isRadioPlaying}
        onToggleRadio={handleToggleRadio}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Live Scores Ticker */}
      <LiveScoresTicker
        matches={matches}
        selectedSport={selectedSport}
        onSelectSport={setSelectedSport}
        onSelectMatch={(m) => setActiveMatchForModal(m)}
        activeMatchId={marqueeMatch.id}
      />

      {/* Main Content Arena */}
      <main className="flex-1 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8 space-y-12 w-full">
        {/* Hero Marquee Match Spotlight */}
        <div id="live">
          <HeroMatchSpotlight
            match={marqueeMatch}
            onOpenMatchCenter={(m) => setActiveMatchForModal(m)}
            onToggleRadio={handleToggleRadio}
            isRadioPlaying={isRadioPlaying}
            onSimulateAction={handleSimulateAction}
          />
        </div>

        {/* Tactical Pitch Spotlight & Live Radio Bento Row */}
        <div id="scores" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Tactical Pitch Full View */}
          <div className="lg:col-span-8">
            <TacticalPitch
              homeLineup={marqueeMatch.homeLineup}
              awayLineup={marqueeMatch.awayLineup}
              homeColor={marqueeMatch.homeTeam.color}
              awayColor={marqueeMatch.awayTeam.color}
              homeName={marqueeMatch.homeTeam.shortName}
              awayName={marqueeMatch.awayTeam.shortName}
            />
          </div>

          {/* Quick Matchday Audio & Fast Insights */}
          <div className="lg:col-span-4 space-y-6">
            {/* Live Audio Broadcast Card */}
            <div className="rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-900 to-slate-950 p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <span className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
                  <span className="relative flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
                  </span>
                  ON AIR · LIVE COMMENTARY
                </span>
                <span className="text-[11px] font-mono text-slate-400">34.2k tuning in</span>
              </div>

              <h3 className="font-display text-lg font-bold text-white mb-1">
                SPOST European Matchday Radio
              </h3>
              <p className="text-xs text-slate-400 mb-5 leading-relaxed">
                Ball-by-ball broadcast from Emirates Stadium with Ian Darke & Ally McCoist.
              </p>

              <button
                onClick={handleToggleRadio}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-white border border-slate-700 py-3 text-xs font-bold transition-all shadow-md active:scale-95"
              >
                <Radio className={`h-4 w-4 ${isRadioPlaying ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
                <span>{isRadioPlaying ? 'Pause Stream' : 'Tune Into Live Stream'}</span>
              </button>
            </div>

            {/* Matchday Quick Stats & Odds Card */}
            <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-6 shadow-xl">
              <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-3">
                <h4 className="font-display text-xs font-bold text-slate-200 uppercase tracking-wider">
                  Win Probability Model
                </h4>
                <span className="text-[10px] font-mono text-emerald-400">Live 82&apos;</span>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Arsenal</span>
                    <span className="font-mono font-bold text-emerald-400">74%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 w-[74%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Draw</span>
                    <span className="font-mono font-bold text-slate-400">18%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-slate-600 w-[18%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-slate-300 mb-1">
                    <span>Manchester City</span>
                    <span className="font-mono font-bold text-sky-400">8%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-sky-500 w-[8%]" />
                  </div>
                </div>
              </div>

              <button
                onClick={() => setActiveMatchForModal(marqueeMatch)}
                className="mt-5 w-full flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                <span>View Full Tactical Timeline</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Standings Table Section */}
        <div id="standings">
          <StandingsTable />
        </div>

        {/* Fan Predictions Arena */}
        <div id="predictions">
          <FanPredictions />
        </div>

        {/* In-depth Editorial Journalism & Tactical Dossiers */}
        <div id="news">
          <NewsSection
            articles={ARTICLES_DATA}
            onSelectArticle={(art) => setSelectedArticle(art)}
          />
        </div>
      </main>

      {/* Footer */}
      <Footer />

      {/* Match Center Deep Modal */}
      <MatchCenterModal
        match={activeMatchForModal}
        onClose={() => setActiveMatchForModal(null)}
        onToggleRadio={handleToggleRadio}
        isRadioPlaying={isRadioPlaying}
      />

      {/* Article Reader Modal */}
      <ArticleModal
        article={selectedArticle}
        onClose={() => setSelectedArticle(null)}
      />

      {/* Global Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        matches={matches}
        articles={ARTICLES_DATA}
        onSelectMatch={(m) => {
          setActiveMatchForModal(m);
          setIsSearchOpen(false);
        }}
        onSelectArticle={(a) => {
          setSelectedArticle(a);
          setIsSearchOpen(false);
        }}
      />

      {/* Floating Audio Commentary Player */}
      {isRadioOpen && (
        <AudioBroadcastPlayer
          isPlaying={isRadioPlaying}
          onTogglePlay={() => setIsRadioPlaying(!isRadioPlaying)}
          onClose={() => {
            setIsRadioOpen(false);
            setIsRadioPlaying(false);
          }}
        />
      )}
    </div>
  );
}
