import React, { useState } from 'react';
import { Article } from '../types/sports';
import { X, Bookmark, Share2, ThumbsUp, Flame, Check, MessageSquare } from 'lucide-react';

interface ArticleModalProps {
  article: Article | null;
  onClose: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [reactions, setReactions] = useState<{ helpful: number; fire: number }>({
    helpful: 124,
    fire: 89,
  });
  const [userReacted, setUserReacted] = useState<string | null>(null);

  if (!article) return null;

  const handleShare = () => {
    navigator.clipboard?.writeText?.(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReaction = (type: 'helpful' | 'fire') => {
    if (userReacted === type) return;
    setReactions(prev => ({
      ...prev,
      [type]: prev[type] + 1,
    }));
    setUserReacted(type);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div
        className="relative flex flex-col w-full max-w-3xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-auto max-h-[90vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Top Actions */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/60 px-6 py-4">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-semibold text-emerald-400">{article.category}</span>
            <span aria-hidden="true">·</span>
            <span>{article.readTime}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs text-slate-300 hover:text-white transition-colors"
            >
              {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5" />}
              <span>{copied ? 'Link Copied' : 'Share'}</span>
            </button>

            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white transition-colors"
              aria-label="Close article"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Article Body */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10 space-y-6">
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-white leading-tight">
            {article.title}
          </h1>

          {/* Author Byline */}
          <div className="flex items-center gap-3 border-y border-slate-800/80 py-3.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-sm border border-emerald-500/30">
              {article.author.avatarInitials}
            </div>
            <div>
              <div className="text-sm font-semibold text-slate-200">{article.author.name}</div>
              <div className="text-xs text-slate-400">
                {article.author.role} · Published {article.publishedAt}
              </div>
            </div>
          </div>

          {/* Lead Paragraph */}
          <p className="text-base sm:text-lg font-medium text-slate-200 leading-relaxed italic border-l-2 border-emerald-500 pl-4">
            {article.excerpt}
          </p>

          {/* Full Content */}
          <div className="space-y-4 text-sm sm:text-base text-slate-300 leading-relaxed font-sans">
            {article.content.map((p, idx) => (
              <p key={idx}>{p}</p>
            ))}
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 pt-4 border-t border-slate-800">
            {article.tags.map((tag) => (
              <span
                key={tag}
                className="text-xs text-slate-400 bg-slate-950 px-2.5 py-1 rounded border border-slate-800"
              >
                #{tag}
              </span>
            ))}
          </div>

          {/* Reader Feedback */}
          <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 flex items-center justify-between">
            <span className="text-xs text-slate-400">Was this tactical breakdown insightful?</span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleReaction('helpful')}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  userReacted === 'helpful'
                    ? 'border-emerald-500 text-emerald-400 bg-emerald-500/10'
                    : 'border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <ThumbsUp className="h-3.5 w-3.5" />
                <span>{reactions.helpful}</span>
              </button>

              <button
                onClick={() => handleReaction('fire')}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium border transition-colors ${
                  userReacted === 'fire'
                    ? 'border-amber-500 text-amber-400 bg-amber-500/10'
                    : 'border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <Flame className="h-3.5 w-3.5" />
                <span>{reactions.fire}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-slate-800 bg-slate-950/60 px-6 py-3">
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <MessageSquare className="h-3.5 w-3.5" />
            <span>{article.commentsCount} fan comments</span>
          </div>

          <button
            onClick={onClose}
            className="rounded-lg bg-slate-800 px-4 py-1.5 text-xs font-medium text-white hover:bg-slate-700 transition-colors"
          >
            Done Reading
          </button>
        </div>
      </div>
    </div>
  );
};
