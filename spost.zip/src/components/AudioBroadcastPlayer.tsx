import React, { useState } from 'react';
import { BROADCAST_STATIONS } from '../data/sportsData';
import { Play, Pause, Volume2, VolumeX, Radio, Users, ChevronUp, ChevronDown, X } from 'lucide-react';

interface AudioBroadcastPlayerProps {
  isPlaying: boolean;
  onTogglePlay: () => void;
  onClose: () => void;
}

export const AudioBroadcastPlayer: React.FC<AudioBroadcastPlayerProps> = ({
  isPlaying,
  onTogglePlay,
  onClose,
}) => {
  const [selectedStationIndex, setSelectedStationIndex] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(80);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  const currentStation = BROADCAST_STATIONS[selectedStationIndex];

  return (
    <div className="fixed bottom-4 right-4 z-40 w-[92vw] max-w-md rounded-2xl border border-slate-700/80 bg-slate-900/95 p-4 shadow-2xl backdrop-blur-md">
      {/* Top row */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className={`absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75 ${isPlaying ? 'animate-ping' : ''}`} />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
          </span>
          <span className="font-mono text-xs font-bold tracking-wider text-emerald-400">
            SPOST MATCHDAY RADIO
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-slate-400 hover:text-white transition-colors"
            aria-label="Toggle station list"
          >
            {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
          </button>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
            aria-label="Close radio"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main player display */}
      <div className="mt-3 flex items-center justify-between gap-4">
        <div className="flex-1 truncate">
          <div className="flex items-center gap-2">
            <h4 className="font-display text-sm font-bold text-white truncate">
              {currentStation.title}
            </h4>
          </div>
          <p className="text-[11px] text-slate-400 truncate">
            {currentStation.commentators} · {currentStation.league}
          </p>

          <div className="mt-1 flex items-center gap-3 text-[10px] text-slate-400 font-mono">
            <span className="flex items-center gap-1 text-slate-400">
              <Users className="h-3 w-3" />
              <span>{currentStation.listeners.toLocaleString()} listeners</span>
            </span>
            <span>·</span>
            <span className="text-emerald-400 font-semibold">{currentStation.duration}</span>
          </div>
        </div>

        {/* Audio Visualizer & Play Controls */}
        <div className="flex items-center gap-3">
          {/* Animated sound bars */}
          <div className="flex h-5 items-end gap-0.5">
            {[40, 90, 60, 100, 75, 45].map((h, i) => (
              <div
                key={i}
                className="w-1 rounded-full bg-emerald-500 transition-all duration-300"
                style={{
                  height: isPlaying ? `${h}%` : '20%',
                  opacity: isPlaying ? 1 : 0.4,
                }}
              />
            ))}
          </div>

          <button
            onClick={onTogglePlay}
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500 text-slate-950 transition-all hover:bg-emerald-400 shadow-md shadow-emerald-500/20 active:scale-95"
            aria-label={isPlaying ? 'Pause broadcast' : 'Play broadcast'}
          >
            {isPlaying ? (
              <Pause className="h-5 w-5 fill-slate-950" />
            ) : (
              <Play className="h-5 w-5 fill-slate-950 ml-0.5" />
            )}
          </button>
        </div>
      </div>

      {/* Expanded Station Switcher */}
      {isExpanded && (
        <div className="mt-4 space-y-2 border-t border-slate-800 pt-3">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
            Available Commentary Streams
          </span>
          {BROADCAST_STATIONS.map((station, index) => (
            <button
              key={station.id}
              onClick={() => setSelectedStationIndex(index)}
              className={`w-full rounded-lg p-2 text-left text-xs transition-colors flex items-center justify-between ${
                selectedStationIndex === index
                  ? 'bg-slate-800 text-emerald-300 font-semibold'
                  : 'text-slate-300 hover:bg-slate-850'
              }`}
            >
              <div className="truncate pr-2">
                <div className="font-medium text-white">{station.title}</div>
                <div className="text-[10px] text-slate-400">{station.commentators}</div>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 shrink-0">
                {station.duration}
              </span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
