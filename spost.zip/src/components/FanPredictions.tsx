import React, { useState } from 'react';
import { FAN_POLLS } from '../data/sportsData';
import { FanPredictionPoll } from '../types/sports';
import { Vote, CheckCircle2, TrendingUp, Clock } from 'lucide-react';

export const FanPredictions: React.FC = () => {
  const [polls, setPolls] = useState<FanPredictionPoll[]>(FAN_POLLS);

  const handleVote = (pollId: string, optionId: string) => {
    setPolls(prev =>
      prev.map(poll => {
        if (poll.id !== pollId || poll.userVotedId) return poll;

        return {
          ...poll,
          userVotedId: optionId,
          totalVotes: poll.totalVotes + 1,
          options: poll.options.map(opt =>
            opt.id === optionId ? { ...opt, votes: opt.votes + 1 } : opt
          ),
        };
      })
    );
  };

  return (
    <section className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white">
            Fan Prediction Arena & Community Odds
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Cast your matchday forecast and track real-time crowd consensus
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
          <TrendingUp className="h-4 w-4" />
          <span>Over 14,000 fan votes locked in today</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {polls.map((poll) => {
          const hasVoted = Boolean(poll.userVotedId);

          return (
            <div
              key={poll.id}
              className="flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/90 p-5 shadow-lg"
            >
              <div>
                {/* Meta info */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                  <span className="font-medium text-emerald-400 uppercase tracking-wider">
                    {poll.sport}
                  </span>
                  <span className="flex items-center gap-1 text-slate-400">
                    <Clock className="h-3 w-3" />
                    <span>{poll.deadline}</span>
                  </span>
                </div>

                <h3 className="font-display text-base font-bold text-white mb-1">
                  {poll.title}
                </h3>
                <p className="text-xs text-slate-400 mb-4">{poll.matchContext}</p>

                {/* Options List */}
                <div className="space-y-2.5">
                  {poll.options.map((opt) => {
                    const percentage = Math.round((opt.votes / poll.totalVotes) * 100) || 0;
                    const isUserChoice = poll.userVotedId === opt.id;

                    return (
                      <button
                        key={opt.id}
                        disabled={hasVoted}
                        onClick={() => handleVote(poll.id, opt.id)}
                        className={`group relative w-full overflow-hidden rounded-lg border p-3 text-left transition-all ${
                          isUserChoice
                            ? 'border-emerald-500 bg-emerald-950/30'
                            : hasVoted
                            ? 'border-slate-800/80 bg-slate-950/50 cursor-default'
                            : 'border-slate-800 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-850'
                        }`}
                      >
                        {/* Progress Fill Bar */}
                        {hasVoted && (
                          <div
                            className={`absolute inset-0 opacity-20 transition-all duration-700 ${
                              isUserChoice ? 'bg-emerald-500' : 'bg-slate-700'
                            }`}
                            style={{ width: `${percentage}%` }}
                          />
                        )}

                        <div className="relative z-10 flex items-center justify-between text-xs">
                          <span className={`font-medium ${isUserChoice ? 'text-emerald-300 font-semibold' : 'text-slate-200'}`}>
                            {opt.label}
                          </span>

                          {hasVoted ? (
                            <span className="font-mono text-xs font-bold text-white tabular-nums">
                              {percentage}%
                            </span>
                          ) : (
                            <span className="text-[11px] text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity">
                              Vote
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Poll footer */}
              <div className="mt-4 flex items-center justify-between border-t border-slate-800/80 pt-3 text-[11px] text-slate-400">
                <span className="font-mono tabular-nums">
                  {poll.totalVotes.toLocaleString()} total votes
                </span>

                {hasVoted && (
                  <span className="flex items-center gap-1 text-emerald-400 font-medium">
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    <span>Pick Saved</span>
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
