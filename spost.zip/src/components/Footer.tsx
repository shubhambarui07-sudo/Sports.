import React, { useState } from 'react';
import { Mail, CheckCircle2 } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    setError('');
    setSubscribed(true);
  };

  return (
    <footer className="border-t border-slate-800 bg-slate-950 text-slate-400">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand & Purpose */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <span className="flex h-7 w-7 items-center justify-center rounded bg-emerald-500 font-display text-xs font-black text-slate-950">
                S
              </span>
              <span className="font-display font-extrabold text-lg text-white">SPOST</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              The premier global sports network delivering live tactical feeds, matchday telemetry, official standings, and long-form athletic analysis.
            </p>
            <div className="text-[11px] text-slate-400">
              Broadcasting globally across football, basketball, motorsport, and grand slam tournaments.
            </div>
          </div>

          {/* Sports Coverage */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Coverage
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">UEFA Champions League</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">English Premier League</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">NBA & Postseason Showcase</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Formula 1 World Championship</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Grand Slam Tennis & Majors</a></li>
            </ul>
          </div>

          {/* Editorial & Community */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Journalism & Tools
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Tactical Dossiers</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Expected Goals (xG) Lab</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Matchday Audio Commentary</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Fan Prediction Consensus</a></li>
              <li><a href="#" className="hover:text-emerald-400 transition-colors">Editorial Standards & Ethics</a></li>
            </ul>
          </div>

          {/* Newsletter Alert */}
          <div>
            <h4 className="font-display text-xs font-bold uppercase tracking-wider text-slate-200 mb-3">
              Matchday Morning Brief
            </h4>
            <p className="text-xs text-slate-400 mb-3">
              Curated tactical breakdowns and fixture alerts delivered at 07:00 GMT.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2 rounded-lg bg-emerald-950/40 border border-emerald-500/30 p-3 text-xs text-emerald-300">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
                <span>Subscribed! Check your inbox for tomorrow’s preview.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="analyst@domain.com"
                    className="w-full rounded-lg border border-slate-800 bg-slate-900 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                  />
                  <button
                    type="submit"
                    className="shrink-0 rounded-lg bg-emerald-500 px-3 py-2 text-xs font-bold text-slate-950 hover:bg-emerald-400 transition-colors"
                  >
                    Join
                  </button>
                </div>
                {error && <p className="text-[11px] text-rose-400">{error}</p>}
              </form>
            )}
          </div>
        </div>

        {/* Quiet Baseline */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-slate-800/80 pt-6 text-xs text-slate-400">
          <div>© {new Date().getFullYear()} SPOST Media & Athletic Intelligence. All rights reserved.</div>
          <div className="flex items-center gap-4 text-xs">
            <a href="#" className="hover:text-slate-300 transition-colors">Privacy Policy</a>
            <span aria-hidden="true">·</span>
            <a href="#" className="hover:text-slate-300 transition-colors">Terms of Service</a>
            <span aria-hidden="true">·</span>
            <a href="#" className="hover:text-slate-300 transition-colors">Cookie Preferences</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
