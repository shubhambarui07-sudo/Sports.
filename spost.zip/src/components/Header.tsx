import React from 'react';
import { Radio, Search, Bell } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isRadioPlaying: boolean;
  onToggleRadio: () => void;
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  isRadioPlaying,
  onToggleRadio,
  onOpenSearch,
}) => {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-slate-950/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectTab('live');
          }}
          className="group flex items-center gap-2 text-xl font-black tracking-wider text-white transition-opacity hover:opacity-90"
        >
          <span className="flex h-8 w-8 items-center justify-center rounded bg-emerald-500 font-display text-sm font-black text-slate-950 shadow-sm shadow-emerald-500/30">
            S
          </span>
          <span className="font-display tracking-tight text-white">SPOST</span>
        </a>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden items-center gap-8 md:flex">
          <button
            onClick={() => onSelectTab('live')}
            className={`whitespace-nowrap text-sm font-medium transition-colors ${
              activeTab === 'live'
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Live Matches
          </button>
          <button
            onClick={() => onSelectTab('scores')}
            className={`whitespace-nowrap text-sm font-medium transition-colors ${
              activeTab === 'scores'
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Scores & Fixtures
          </button>
          <button
            onClick={() => onSelectTab('standings')}
            className={`whitespace-nowrap text-sm font-medium transition-colors ${
              activeTab === 'standings'
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Standings
          </button>
          <button
            onClick={() => onSelectTab('news')}
            className={`whitespace-nowrap text-sm font-medium transition-colors ${
              activeTab === 'news'
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Analysis & News
          </button>
          <button
            onClick={() => onSelectTab('predictions')}
            className={`whitespace-nowrap text-sm font-medium transition-colors ${
              activeTab === 'predictions'
                ? 'text-emerald-400 font-semibold'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            Fan Predictions
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenSearch}
            aria-label="Search matches or teams"
            className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-slate-900 hover:text-white transition-colors"
          >
            <Search className="h-4 w-4" />
          </button>

          <button
            onClick={onToggleRadio}
            className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-semibold tracking-wide transition-all ${
              isRadioPlaying
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700 hover:text-white'
            }`}
          >
            <Radio className={`h-3.5 w-3.5 ${isRadioPlaying ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
            <span className="hidden sm:inline">
              {isRadioPlaying ? 'Radio On Air' : 'Live Match Audio'}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
