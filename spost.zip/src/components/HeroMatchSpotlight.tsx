import React from 'react';
import { Match } from '../types/sports';
import { Play, Volume2, ShieldAlert, Target, Award, ArrowUpRight, Sparkles } from 'lucide-react';

interface HeroMatchSpotlightProps {
  match: Match;
  onOpenMatchCenter: (match: Match) => void;
  onToggleRadio: () => void;
  isRadioPlaying: boolean;
  onSimulateAction: () => void;
}

export const HeroMatchSpotlight: React.FC<HeroMatchSpotlightProps> = ({
  match,
  onOpenMatchCenter,
  onToggleRadio,
  isRadioPlaying,
  onSimulateAction,
}) => {
  const homePossession = match.stats.possession[0];
  const awayPossession = match.stats.possession[1];

  return (
    <section className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 p-6 sm:p-8 shadow-2xl">
      {/* Background athletic stadium atmosphere overlay */}
      <div className="pointer-events-none absolute -right-20 -top-20 h-96 w-96 rounded-full bg-emerald-500/10 blur-3xl" />
      <div className="pointer-events-none absolute -left-20 -bottom-20 h-96 w-96 rounded-full bg-blue-600/10 blur-3xl" />

      {/* Header bar: League, Matchday, Venue */}
      <div className="relative z-10 mb-6 flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
        <div className="flex items-center gap-2 text-xs text-slate-300">
          <span className="font-semibold text-emerald-400">MARQUEE MATCHDAY</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-200 font-medium">{match.league}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-400">{match.venue}</span>
        </div>

        {/* Live indicator & Simulation trigger */}
        <div className="flex items-center gap-2">
          <button
            onClick={onSimulateAction}
            title="Simulate in-game event and live commentary"
            className="flex items-center gap-1.5 rounded-md border border-slate-700 bg-slate-800/80 px-2.5 py-1 text-xs font-medium text-slate-200 transition-colors hover:border-emerald-500 hover:text-emerald-400"
          >
            <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
            <span>Simulate Match Event</span>
          </button>

          <div className="flex items-center gap-1.5 rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 font-mono text-xs font-bold text-emerald-400">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
            </span>
            <span>{match.statusText}</span>
          </div>
        </div>
      </div>

      {/* Main Score & Teams Arena */}
      <div className="relative z-10 grid grid-cols-1 items-center gap-6 lg:grid-cols-12">
        {/* Home Team */}
        <div className="flex items-center gap-4 lg:col-span-4">
          <div
            className="flex h-16 w-16 sm:h-20 sm:w-20 shrink-0 items-center justify-center rounded-2xl border border-white/10 text-xl sm:text-2xl font-black text-white shadow-xl transition-transform hover:scale-105"
            style={{ backgroundColor: match.homeTeam.color }}
          >
            {match.homeTeam.code}
          </div>
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white">
              {match.homeTeam.name}
            </h2>
            <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
              <span>Home Advantage</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-400 font-medium">Rank #1 (EPL)</span>
            </div>
          </div>
        </div>

        {/* Center Score & Match Pulse */}
        <div className="flex flex-col items-center justify-center text-center lg:col-span-4">
          <div className="flex items-center gap-4 font-mono text-5xl sm:text-6xl font-black tracking-tight text-white tabular-nums drop-shadow-md">
            <span>{match.homeTeam.score}</span>
            <span className="text-slate-600">:</span>
            <span>{match.awayTeam.score}</span>
          </div>

          <p className="mt-2 text-xs text-slate-400 max-w-xs">
            {match.events.length > 0
              ? `Latest: ${match.events[match.events.length - 1].player} (${match.events[match.events.length - 1].minute}')`
              : 'Match underway'}
          </p>

          {/* Key Events Timeline list */}
          <div className="mt-3 flex flex-wrap justify-center gap-x-3 gap-y-1 text-[11px] text-slate-400">
            {match.events.filter(e => e.type === 'goal').map((goal, idx) => (
              <span key={idx} className="flex items-center gap-1">
                <span className="text-emerald-400 font-mono font-semibold">{goal.minute}&apos;</span>
                <span className="text-slate-300">{goal.player}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Away Team */}
        <div className="flex items-center justify-start lg:justify-end gap-4 lg:col-span-4">
          <div className="text-left lg:text-right order-2 lg:order-1">
            <h2 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white">
              {match.awayTeam.name}
            </h2>
            <div className="mt-1 flex items-center justify-start lg:justify-end gap-2 text-xs text-slate-400">
              <span className="text-sky-400 font-medium">Rank #2 (EPL)</span>
              <span aria-hidden="true">·</span>
              <span>Away</span>
            </div>
          </div>
          <div
            className="flex h-16 w-16 sm:h-20 sm:w-20 shrink-0 items-center justify-center rounded-2xl border border-white/10 text-xl sm:text-2xl font-black text-white shadow-xl transition-transform hover:scale-105 order-1 lg:order-2"
            style={{ backgroundColor: match.awayTeam.color }}
          >
            {match.awayTeam.code}
          </div>
        </div>
      </div>

      {/* Live Match Stats Bar */}
      <div className="relative z-10 mt-8 rounded-xl border border-slate-800 bg-slate-950/80 p-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Possession Bar */}
          <div>
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
              <span className="font-mono tabular-nums text-slate-200">{homePossession}%</span>
              <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400">
                Possession
              </span>
              <span className="font-mono tabular-nums text-slate-200">{awayPossession}%</span>
            </div>
            <div className="flex h-2 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full bg-emerald-500 transition-all duration-500"
                style={{ width: `${homePossession}%` }}
              />
              <div
                className="h-full bg-sky-500 transition-all duration-500"
                style={{ width: `${awayPossession}%` }}
              />
            </div>
          </div>

          {/* Expected Goals (xG) */}
          <div className="flex flex-col justify-center text-center border-t sm:border-t-0 sm:border-x border-slate-800/80 pt-2 sm:pt-0 sm:px-4">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-0.5">
              Expected Goals (xG)
            </span>
            <div className="flex items-center justify-center gap-3 font-mono text-sm font-bold text-white">
              <span className="text-emerald-400">{match.stats.xG ? match.stats.xG[0] : 1.8}</span>
              <span className="text-slate-600">vs</span>
              <span className="text-sky-400">{match.stats.xG ? match.stats.xG[1] : 1.2}</span>
            </div>
          </div>

          {/* Shots on Target */}
          <div className="flex flex-col justify-center text-center border-t sm:border-t-0 border-slate-800/80 pt-2 sm:pt-0">
            <span className="text-[11px] font-medium uppercase tracking-wider text-slate-400 mb-0.5">
              Shots On Target / Total
            </span>
            <div className="flex items-center justify-center gap-3 font-mono text-sm font-bold text-slate-200">
              <span>{match.stats.shotsOnTarget[0]} / {match.stats.shots[0]}</span>
              <span className="text-slate-600">·</span>
              <span>{match.stats.shotsOnTarget[1]} / {match.stats.shots[1]}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Action CTA Bar */}
      <div className="relative z-10 mt-6 flex flex-wrap items-center justify-between gap-4 pt-2">
        <p className="text-xs text-slate-400 max-w-xl line-clamp-1">
          {match.summary}
        </p>

        <div className="flex items-center gap-3">
          <button
            onClick={onToggleRadio}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-semibold transition-all ${
              isRadioPlaying
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'border border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-750 hover:text-white'
            }`}
          >
            <Volume2 className="h-4 w-4 text-emerald-400" />
            <span>{isRadioPlaying ? 'Pause Audio' : 'Listen Live Radio'}</span>
          </button>

          <button
            onClick={() => onOpenMatchCenter(match)}
            className="flex items-center gap-2 rounded-lg bg-emerald-500 px-5 py-2 text-xs font-bold text-slate-950 transition-all hover:bg-emerald-400 shadow-lg shadow-emerald-500/20 active:scale-[0.98]"
          >
            <span>Full Match Center & Tactics</span>
            <ArrowUpRight className="h-4 w-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
