import React from 'react';
import { Match, SportType } from '../types/sports';
import { ChevronRight, Flame } from 'lucide-react';

interface LiveScoresTickerProps {
  matches: Match[];
  selectedSport: SportType;
  onSelectSport: (sport: SportType) => void;
  onSelectMatch: (match: Match) => void;
  activeMatchId?: string;
}

const SPORTS_OPTIONS: { id: SportType; label: string }[] = [
  { id: 'all', label: 'All Leagues' },
  { id: 'football', label: 'Football' },
  { id: 'basketball', label: 'Basketball' },
  { id: 'formula1', label: 'Formula 1' },
  { id: 'tennis', label: 'Tennis' },
  { id: 'cricket', label: 'Cricket' },
];

export const LiveScoresTicker: React.FC<LiveScoresTickerProps> = ({
  matches,
  selectedSport,
  onSelectSport,
  onSelectMatch,
  activeMatchId,
}) => {
  const filteredMatches = selectedSport === 'all'
    ? matches
    : matches.filter((m) => m.sport === selectedSport);

  return (
    <div className="border-b border-slate-850 bg-slate-900/90 py-3 backdrop-blur-sm">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Sport switcher control */}
        <div className="mb-2.5 flex items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            <span className="mr-2 flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
              </span>
              LIVE
            </span>
            {SPORTS_OPTIONS.map((sport) => (
              <button
                key={sport.id}
                onClick={() => onSelectSport(sport.id)}
                className={`whitespace-nowrap rounded-md px-2.5 py-1 text-xs font-medium transition-all ${
                  selectedSport === sport.id
                    ? 'bg-slate-800 text-white shadow-sm ring-1 ring-slate-700'
                    : 'text-slate-400 hover:bg-slate-850 hover:text-slate-200'
                }`}
              >
                {sport.label}
              </button>
            ))}
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400">
            <Flame className="h-3.5 w-3.5 text-amber-400" />
            <span>5 matches in progress</span>
          </div>
        </div>

        {/* Matches Horizontal Scrollbar */}
        <div className="flex gap-3 overflow-x-auto pb-1.5 pt-0.5 no-scrollbar">
          {filteredMatches.map((match) => {
            const isSelected = activeMatchId === match.id;
            const isLive = match.status === 'LIVE';

            return (
              <button
                key={match.id}
                onClick={() => onSelectMatch(match)}
                className={`group flex min-w-[260px] max-w-[280px] shrink-0 flex-col rounded-lg border p-3 text-left transition-all ${
                  isSelected
                    ? 'border-emerald-500/60 bg-slate-850/90 shadow-md shadow-emerald-500/10'
                    : 'border-slate-800/80 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-850/60'
                }`}
              >
                {/* League & Time */}
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                  <span className="truncate max-w-[170px] font-medium text-slate-300">
                    {match.league}
                  </span>
                  <span
                    className={`font-mono text-[10px] font-semibold tabular-nums ${
                      isLive ? 'text-emerald-400' : 'text-slate-400'
                    }`}
                  >
                    {match.statusText}
                  </span>
                </div>

                {/* Home Team */}
                <div className="flex items-center justify-between py-0.5">
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[10px] font-bold text-white shadow-sm"
                      style={{ backgroundColor: match.homeTeam.color }}
                    >
                      {match.homeTeam.code.slice(0, 2)}
                    </span>
                    <span className="truncate text-xs font-semibold text-slate-100">
                      {match.homeTeam.shortName}
                    </span>
                  </div>
                  <span className="font-mono text-sm font-bold tabular-nums text-white">
                    {match.homeTeam.score}
                  </span>
                </div>

                {/* Away Team */}
                <div className="flex items-center justify-between py-0.5">
                  <div className="flex items-center gap-2 truncate">
                    <span
                      className="flex h-5 w-5 shrink-0 items-center justify-center rounded text-[10px] font-bold text-white shadow-sm"
                      style={{ backgroundColor: match.awayTeam.color }}
                    >
                      {match.awayTeam.code.slice(0, 2)}
                    </span>
                    <span className="truncate text-xs font-semibold text-slate-100">
                      {match.awayTeam.shortName}
                    </span>
                  </div>
                  <span className="font-mono text-sm font-bold tabular-nums text-white">
                    {match.awayTeam.score}
                  </span>
                </div>

                {/* Footer preview */}
                <div className="mt-2 flex items-center justify-between border-t border-slate-800/60 pt-1.5 text-[10px] text-slate-400">
                  <span className="truncate text-slate-500">
                    {match.events.length > 0 ? match.events[match.events.length - 1].player : match.venue}
                  </span>
                  <span className="flex items-center text-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity">
                    View Match <ChevronRight className="h-3 w-3 ml-0.5" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
