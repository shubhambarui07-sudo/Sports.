import React, { useState } from 'react';
import { Match, MatchEvent } from '../types/sports';
import { TacticalPitch } from './TacticalPitch';
import { X, Clock, Award, Shield, Users, Activity, BarChart3, Radio } from 'lucide-react';

interface MatchCenterModalProps {
  match: Match | null;
  onClose: () => void;
  onToggleRadio: () => void;
  isRadioPlaying: boolean;
}

export const MatchCenterModal: React.FC<MatchCenterModalProps> = ({
  match,
  onClose,
  onToggleRadio,
  isRadioPlaying,
}) => {
  const [activeTab, setActiveTab] = useState<'pitch' | 'timeline' | 'stats' | 'lineups'>('pitch');
  const [timelineFilter, setTimelineFilter] = useState<'all' | 'goal' | 'card'>('all');

  if (!match) return null;

  const filteredEvents = match.events.filter((evt) => {
    if (timelineFilter === 'goal') return evt.type === 'goal' || evt.type === 'three_pointer' || evt.type === 'break_point' || evt.type === 'wicket';
    if (timelineFilter === 'card') return evt.type === 'yellow_card' || evt.type === 'red_card';
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div
        className="relative flex flex-col w-full max-w-5xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden my-auto max-h-[92vh]"
        role="dialog"
        aria-modal="true"
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-950/70 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold text-emerald-400">MATCH CENTER</span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-300">{match.league}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onToggleRadio}
              className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-emerald-400 transition-colors"
            >
              <Radio className={`h-3.5 w-3.5 ${isRadioPlaying ? 'text-emerald-400' : 'text-slate-400'}`} />
              <span>{isRadioPlaying ? 'Radio Active' : 'Listen Live'}</span>
            </button>

            <button
              onClick={onClose}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white transition-colors"
              aria-label="Close modal"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Scoreboard Header */}
        <div className="border-b border-slate-800 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 px-6 py-6">
          <div className="grid grid-cols-3 items-center">
            {/* Home Team */}
            <div className="flex items-center gap-3">
              <div
                className="flex h-12 w-12 sm:h-14 sm:w-14 shrink-0 items-center justify-center rounded-xl font-bold text-white text-lg shadow-md"
                style={{ backgroundColor: match.homeTeam.color }}
              >
                {match.homeTeam.code}
              </div>
              <div>
                <h3 className="font-display font-bold text-base sm:text-lg text-white">
                  {match.homeTeam.name}
                </h3>
                <span className="text-xs text-slate-400">Home</span>
              </div>
            </div>

            {/* Score & Status */}
            <div className="text-center">
              <div className="font-mono text-3xl sm:text-4xl font-extrabold text-white tabular-nums tracking-wider">
                {match.homeTeam.score} - {match.awayTeam.score}
              </div>
              <div className="mt-1 flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-400">
                <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>{match.statusText}</span>
              </div>
            </div>

            {/* Away Team */}
            <div className="flex items-center justify-end gap-3 text-right">
              <div>
                <h3 className="font-display font-bold text-base sm:text-lg text-white">
                  {match.awayTeam.name}
                </h3>
                <span className="text-xs text-slate-400">Away</span>
              </div>
              <div
                className="flex h-12 w-12 sm:h-14 sm:w-14 shrink-0 items-center justify-center rounded-xl font-bold text-white text-lg shadow-md"
                style={{ backgroundColor: match.awayTeam.color }}
              >
                {match.awayTeam.code}
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 bg-slate-950/40 px-6 py-2.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('pitch')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all ${
              activeTab === 'pitch'
                ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Activity className="h-3.5 w-3.5" />
            <span>Tactical Pitch</span>
          </button>

          <button
            onClick={() => setActiveTab('timeline')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all ${
              activeTab === 'timeline'
                ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="h-3.5 w-3.5" />
            <span>Play-by-Play Commentary</span>
          </button>

          <button
            onClick={() => setActiveTab('stats')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all ${
              activeTab === 'stats'
                ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BarChart3 className="h-3.5 w-3.5" />
            <span>Key Match Statistics</span>
          </button>

          <button
            onClick={() => setActiveTab('lineups')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all ${
              activeTab === 'lineups'
                ? 'bg-emerald-500/20 text-emerald-300 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="h-3.5 w-3.5" />
            <span>Squad Lineups & Ratings</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'pitch' && (
            <div>
              {match.homeLineup.length > 0 ? (
                <TacticalPitch
                  homeLineup={match.homeLineup}
                  awayLineup={match.awayLineup}
                  homeColor={match.homeTeam.color}
                  awayColor={match.awayTeam.color}
                  homeName={match.homeTeam.shortName}
                  awayName={match.awayTeam.shortName}
                />
              ) : (
                <div className="rounded-xl border border-slate-800 bg-slate-950 p-8 text-center text-slate-400">
                  <Activity className="h-8 w-8 text-slate-600 mx-auto mb-2" />
                  <p className="text-sm font-medium text-slate-300">
                    Live court tracking active for {match.league}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Telemetry feeds live spatial position during tournament play.
                  </p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'timeline' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">
                  Official Match Incident Log
                </span>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setTimelineFilter('all')}
                    className={`rounded px-2.5 py-1 text-xs ${
                      timelineFilter === 'all'
                        ? 'bg-slate-800 text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    All Events
                  </button>
                  <button
                    onClick={() => setTimelineFilter('goal')}
                    className={`rounded px-2.5 py-1 text-xs ${
                      timelineFilter === 'goal'
                        ? 'bg-slate-800 text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Goals & Scores
                  </button>
                  <button
                    onClick={() => setTimelineFilter('card')}
                    className={`rounded px-2.5 py-1 text-xs ${
                      timelineFilter === 'card'
                        ? 'bg-slate-800 text-white font-medium'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    Cards
                  </button>
                </div>
              </div>

              <div className="divide-y divide-slate-800/80 rounded-xl border border-slate-800 bg-slate-950/60">
                {filteredEvents.map((evt, idx) => (
                  <div key={idx} className="flex items-start gap-4 p-4 text-xs">
                    <span className="font-mono text-sm font-bold text-emerald-400 tabular-nums">
                      {evt.minute}&apos;
                    </span>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-slate-100">{evt.player}</span>
                        <span className="text-[11px] text-slate-400">
                          ({evt.team === 'home' ? match.homeTeam.shortName : match.awayTeam.shortName})
                        </span>
                      </div>
                      {evt.detail && (
                        <p className="mt-1 text-slate-400">{evt.detail}</p>
                      )}
                    </div>
                    <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">
                      {evt.type.replace('_', ' ')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'stats' && (
            <div className="space-y-5">
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-5">
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-4">
                  Match Statistics Breakdown
                </h4>

                <div className="space-y-4 text-xs">
                  {/* Possession */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span className="font-mono tabular-nums font-bold">{match.stats.possession[0]}%</span>
                      <span className="text-slate-400">Possession</span>
                      <span className="font-mono tabular-nums font-bold">{match.stats.possession[1]}%</span>
                    </div>
                    <div className="flex h-2 rounded-full overflow-hidden bg-slate-800">
                      <div className="bg-emerald-500" style={{ width: `${match.stats.possession[0]}%` }} />
                      <div className="bg-sky-500" style={{ width: `${match.stats.possession[1]}%` }} />
                    </div>
                  </div>

                  {/* Shots on Target */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span className="font-mono tabular-nums font-bold">{match.stats.shotsOnTarget[0]}</span>
                      <span className="text-slate-400">Shots on Target</span>
                      <span className="font-mono tabular-nums font-bold">{match.stats.shotsOnTarget[1]}</span>
                    </div>
                    <div className="flex h-2 rounded-full overflow-hidden bg-slate-800">
                      <div className="bg-emerald-500" style={{ width: `${(match.stats.shotsOnTarget[0] / (match.stats.shotsOnTarget[0] + match.stats.shotsOnTarget[1] || 1)) * 100}%` }} />
                      <div className="bg-sky-500" style={{ width: `${(match.stats.shotsOnTarget[1] / (match.stats.shotsOnTarget[0] + match.stats.shotsOnTarget[1] || 1)) * 100}%` }} />
                    </div>
                  </div>

                  {/* Total Shots */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span className="font-mono tabular-nums font-bold">{match.stats.shots[0]}</span>
                      <span className="text-slate-400">Total Shots</span>
                      <span className="font-mono tabular-nums font-bold">{match.stats.shots[1]}</span>
                    </div>
                  </div>

                  {/* Fouls */}
                  <div>
                    <div className="flex justify-between text-slate-300 mb-1">
                      <span className="font-mono tabular-nums font-bold">{match.stats.fouls[0]}</span>
                      <span className="text-slate-400">Fouls</span>
                      <span className="font-mono tabular-nums font-bold">{match.stats.fouls[1]}</span>
                    </div>
                  </div>

                  {/* Expected Goals */}
                  {match.stats.xG && (
                    <div>
                      <div className="flex justify-between text-slate-300 mb-1">
                        <span className="font-mono tabular-nums font-bold text-emerald-400">{match.stats.xG[0]}</span>
                        <span className="text-slate-400">Expected Goals (xG)</span>
                        <span className="font-mono tabular-nums font-bold text-sky-400">{match.stats.xG[1]}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'lineups' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Home Squad */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
                  <div
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: match.homeTeam.color }}
                  />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {match.homeTeam.name} Starting XI
                  </span>
                </div>
                <div className="divide-y divide-slate-850 text-xs">
                  {match.homeLineup.map((player) => (
                    <div key={player.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-slate-400 w-5 text-right">{player.number}</span>
                        <span className="font-medium text-slate-200">{player.name}</span>
                        {player.isCaptain && <span className="text-[10px] text-amber-400 font-bold">[C]</span>}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-slate-400 font-mono">{player.position}</span>
                        <span className="font-mono text-xs font-bold text-emerald-400 tabular-nums">
                          {player.rating.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Away Squad */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4">
                <div className="flex items-center gap-2 mb-3 pb-2 border-b border-slate-800">
                  <div
                    className="h-3 w-3 rounded-full"
                    style={{ backgroundColor: match.awayTeam.color }}
                  />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {match.awayTeam.name} Starting XI
                  </span>
                </div>
                <div className="divide-y divide-slate-850 text-xs">
                  {match.awayLineup.map((player) => (
                    <div key={player.id} className="flex items-center justify-between py-2">
                      <div className="flex items-center gap-2.5">
                        <span className="font-mono text-slate-400 w-5 text-right">{player.number}</span>
                        <span className="font-medium text-slate-200">{player.name}</span>
                        {player.isCaptain && <span className="text-[10px] text-amber-400 font-bold">[C]</span>}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[11px] text-slate-400 font-mono">{player.position}</span>
                        <span className="font-mono text-xs font-bold text-sky-400 tabular-nums">
                          {player.rating.toFixed(1)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Info */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800 bg-slate-950/70 px-6 py-3 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span>Venue: {match.venue}</span>
            {match.referee && (
              <>
                <span aria-hidden="true">·</span>
                <span>Referee: {match.referee}</span>
              </>
            )}
            {match.attendance && (
              <>
                <span aria-hidden="true">·</span>
                <span>Attendance: {match.attendance}</span>
              </>
            )}
          </div>
          <button
            onClick={onClose}
            className="rounded-lg bg-slate-800 px-4 py-1.5 text-xs font-medium text-white hover:bg-slate-700 transition-colors"
          >
            Close Center
          </button>
        </div>
      </div>
    </div>
  );
};
