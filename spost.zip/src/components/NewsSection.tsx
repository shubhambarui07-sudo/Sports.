import React, { useState } from 'react';
import { Article, SportType } from '../types/sports';
import { MessageSquare, Bookmark, Share2, ArrowRight } from 'lucide-react';

interface NewsSectionProps {
  articles: Article[];
  onSelectArticle: (article: Article) => void;
}

export const NewsSection: React.FC<NewsSectionProps> = ({
  articles,
  onSelectArticle,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [bookmarkedIds, setBookmarkedIds] = useState<Set<string>>(new Set());

  const categories = [
    { id: 'all', label: 'All Stories' },
    { id: 'football', label: 'Football' },
    { id: 'basketball', label: 'Basketball' },
    { id: 'formula1', label: 'Formula 1' },
    { id: 'tennis', label: 'Tennis' },
    { id: 'cricket', label: 'Cricket' },
  ];

  const filteredArticles = selectedCategory === 'all'
    ? articles
    : articles.filter(a => a.sport === selectedCategory);

  const featuredArticle = articles.find(a => a.isFeatured) || articles[0];
  const listArticles = filteredArticles.filter(a => a.id !== featuredArticle.id);

  const toggleBookmark = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setBookmarkedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <section className="space-y-6">
      {/* Section Header with Category Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-white">
            Athletic Dispatch & Tactical Journalism
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Rigorous game breakdowns, high-speed telemetry, and field analysis
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-medium transition-all ${
                selectedCategory === cat.id
                  ? 'bg-slate-800 text-white font-semibold shadow-xs'
                  : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Editorial Banner */}
      {featuredArticle && (
        <article
          onClick={() => onSelectArticle(featuredArticle)}
          className="group relative cursor-pointer overflow-hidden rounded-2xl border border-slate-800 bg-slate-900 transition-all hover:border-slate-700 hover:shadow-xl"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Visual Media Container with Domain Graphics */}
            <div className="relative min-h-[260px] lg:col-span-7 overflow-hidden bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-950 flex items-center justify-center p-8">
              {/* Pitch grid lines abstract visual */}
              <div className="absolute inset-0 opacity-20 pointer-events-none">
                <svg className="w-full h-full" viewBox="0 0 400 250" preserveAspectRatio="none">
                  <path d="M 0,125 L 400,125 M 200,0 L 200,250" stroke="#10b981" strokeWidth="1" strokeDasharray="4 4" />
                  <circle cx="200" cy="125" r="45" stroke="#10b981" strokeWidth="1" fill="none" />
                </svg>
              </div>

              {/* Graphical Marquee Badge */}
              <div className="relative z-10 text-center">
                <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <span className="font-display font-black text-xl">SP</span>
                </div>
                <span className="text-xs uppercase tracking-widest font-mono text-emerald-400/90 font-semibold">
                  FEATURED INVESTIGATION
                </span>
                <h4 className="mt-1 font-display text-lg font-bold text-slate-200 max-w-md mx-auto line-clamp-2">
                  Tactical Geometry & Rest-Defense in 2026
                </h4>
              </div>
            </div>

            {/* Editorial Content */}
            <div className="flex flex-col justify-between p-6 sm:p-8 lg:col-span-5">
              <div>
                {/* Zero-Pill Unboxed Metadata */}
                <div className="flex items-center gap-2 text-xs text-slate-400 mb-3">
                  <span className="font-semibold text-emerald-400">{featuredArticle.category}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredArticle.publishedAt}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featuredArticle.readTime}</span>
                </div>

                <h3 className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                  {featuredArticle.title}
                </h3>

                <p className="mt-3 text-xs sm:text-sm text-slate-300 leading-relaxed line-clamp-3">
                  {featuredArticle.excerpt}
                </p>
              </div>

              {/* Author & Actions */}
              <div className="mt-6 flex items-center justify-between border-t border-slate-800/80 pt-4">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-800 text-[11px] font-bold text-slate-200">
                    {featuredArticle.author.avatarInitials}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">
                      {featuredArticle.author.name}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {featuredArticle.author.role}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={(e) => toggleBookmark(e, featuredArticle.id)}
                    aria-label="Bookmark story"
                    className={`flex h-8 w-8 items-center justify-center rounded-lg transition-colors ${
                      bookmarkedIds.has(featuredArticle.id)
                        ? 'text-emerald-400 bg-emerald-500/10'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Bookmark className="h-4 w-4" />
                  </button>

                  <span className="flex items-center gap-1 text-xs font-semibold text-emerald-400 group-hover:translate-x-0.5 transition-transform">
                    <span>Read Analysis</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </span>
                </div>
              </div>
            </div>
          </div>
        </article>
      )}

      {/* Grid of Secondary Stories */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {listArticles.map((article) => (
          <article
            key={article.id}
            onClick={() => onSelectArticle(article)}
            className="group flex flex-col justify-between rounded-xl border border-slate-800 bg-slate-900/70 p-5 transition-all hover:border-slate-700 hover:bg-slate-850/80 cursor-pointer"
          >
            <div>
              {/* Zero-Pill Unboxed Metadata */}
              <div className="flex items-center gap-2 text-[11px] text-slate-400 mb-2">
                <span className="font-medium text-emerald-400">{article.category}</span>
                <span aria-hidden="true">·</span>
                <span>{article.readTime}</span>
                <span aria-hidden="true">·</span>
                <span>{article.publishedAt}</span>
              </div>

              <h4 className="font-display text-base font-bold tracking-tight text-white group-hover:text-emerald-400 transition-colors">
                {article.title}
              </h4>

              <p className="mt-2 text-xs text-slate-300 leading-relaxed line-clamp-2">
                {article.excerpt}
              </p>
            </div>

            <div className="mt-4 flex items-center justify-between border-t border-slate-800/80 pt-3">
              <span className="text-xs text-slate-400">By {article.author.name}</span>

              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 text-[11px] text-slate-400">
                  <MessageSquare className="h-3 w-3" />
                  <span className="font-mono tabular-nums">{article.commentsCount}</span>
                </span>

                <button
                  onClick={(e) => toggleBookmark(e, article.id)}
                  aria-label="Bookmark story"
                  className={`transition-colors ${
                    bookmarkedIds.has(article.id)
                      ? 'text-emerald-400'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Bookmark className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
    </section>
  );
};
