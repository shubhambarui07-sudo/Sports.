import React, { useState } from 'react';
import { Match, Article } from '../types/sports';
import { Search, X, ChevronRight, Activity, FileText } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  matches: Match[];
  articles: Article[];
  onSelectMatch: (match: Match) => void;
  onSelectArticle: (article: Article) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  matches,
  articles,
  onSelectMatch,
  onSelectArticle,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const cleanQuery = query.toLowerCase().trim();

  const matchedMatches = cleanQuery
    ? matches.filter(
        (m) =>
          m.homeTeam.name.toLowerCase().includes(cleanQuery) ||
          m.awayTeam.name.toLowerCase().includes(cleanQuery) ||
          m.league.toLowerCase().includes(cleanQuery) ||
          m.venue.toLowerCase().includes(cleanQuery)
      )
    : [];

  const matchedArticles = cleanQuery
    ? articles.filter(
        (a) =>
          a.title.toLowerCase().includes(cleanQuery) ||
          a.category.toLowerCase().includes(cleanQuery) ||
          a.tags.some((t) => t.toLowerCase().includes(cleanQuery)) ||
          a.author.name.toLowerCase().includes(cleanQuery)
      )
    : [];

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-20 bg-slate-950/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl overflow-hidden">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 border-b border-slate-800 px-4 py-3.5 bg-slate-950">
          <Search className="h-5 w-5 text-emerald-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search teams (Arsenal, Lakers, Red Bull), sports, leagues, or tactics..."
            className="w-full bg-transparent text-sm text-white placeholder-slate-500 focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-slate-400 hover:text-white"
            >
              Clear
            </button>
          )}
          <button
            onClick={onClose}
            className="flex h-7 w-7 items-center justify-center rounded-lg bg-slate-850 text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-4">
          {!cleanQuery && (
            <div className="py-8 text-center text-xs text-slate-400">
              <p>Type to search across live matches, teams, tactical guides, and players.</p>
              <div className="mt-3 flex justify-center gap-2">
                {['Arsenal', 'Celtics', 'Verstappen', 'Champions League', 'Tactics'].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setQuery(tag)}
                    className="rounded bg-slate-800 px-2 py-1 text-[11px] text-slate-300 hover:bg-slate-700"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          )}

          {cleanQuery && matchedMatches.length === 0 && matchedArticles.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-400">
              No results found for &ldquo;{query}&rdquo;. Try another team or league.
            </div>
          )}

          {/* Matched Matches */}
          {matchedMatches.length > 0 && (
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
                Matches & Fixtures ({matchedMatches.length})
              </span>
              <div className="space-y-1.5">
                {matchedMatches.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => {
                      onSelectMatch(m);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-left text-xs transition-colors hover:border-slate-700 hover:bg-slate-850"
                  >
                    <div className="flex items-center gap-2.5">
                      <Activity className="h-4 w-4 text-emerald-400" />
                      <div>
                        <span className="font-semibold text-white">
                          {m.homeTeam.name} vs {m.awayTeam.name}
                        </span>
                        <span className="text-[11px] text-slate-400 block">{m.league}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 font-mono tabular-nums text-slate-300">
                      <span>{m.statusText}</span>
                      <ChevronRight className="h-3.5 w-3.5 text-slate-500" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Matched Articles */}
          {matchedArticles.length > 0 && (
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
                Editorial Analysis ({matchedArticles.length})
              </span>
              <div className="space-y-1.5">
                {matchedArticles.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => {
                      onSelectArticle(a);
                      onClose();
                    }}
                    className="w-full flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-left text-xs transition-colors hover:border-slate-700 hover:bg-slate-850"
                  >
                    <div className="flex items-center gap-2.5">
                      <FileText className="h-4 w-4 text-sky-400" />
                      <div>
                        <span className="font-semibold text-white line-clamp-1">{a.title}</span>
                        <span className="text-[11px] text-slate-400">{a.category} · {a.readTime}</span>
                      </div>
                    </div>
                    <ChevronRight className="h-3.5 w-3.5 text-slate-500 shrink-0" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
