import React, { useState } from 'react';
import { STANDINGS_DATA } from '../data/sportsData';
import { Trophy, ChevronRight, TrendingUp } from 'lucide-react';

export const StandingsTable: React.FC = () => {
  const [selectedLeague, setSelectedLeague] = useState<'premier_league' | 'nba_east' | 'f1_championship'>('premier_league');

  const leagueLabels = [
    { id: 'premier_league', label: 'Premier League (Football)' },
    { id: 'nba_east', label: 'NBA Eastern (Basketball)' },
    { id: 'f1_championship', label: 'F1 World Championship' },
  ];

  const standings = STANDINGS_DATA[selectedLeague] || [];

  return (
    <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-5 sm:p-6 shadow-xl">
      {/* Table Header & Switcher */}
      <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4">
        <div className="flex items-center gap-2">
          <Trophy className="h-4 w-4 text-emerald-400" />
          <h3 className="font-display text-lg font-bold text-white">
            Official League Standings
          </h3>
        </div>

        {/* League Selector Tabs */}
        <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1 text-xs">
          {leagueLabels.map((league) => (
            <button
              key={league.id}
              onClick={() => setSelectedLeague(league.id as any)}
              className={`rounded px-3 py-1 font-medium transition-all ${
                selectedLeague === league.id
                  ? 'bg-slate-800 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {league.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table Data */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-[11px] font-semibold uppercase tracking-wider text-slate-400">
              <th className="py-2.5 pl-2 pr-3 w-8">#</th>
              <th className="py-2.5 px-3">Team / Competitor</th>
              <th className="py-2.5 px-3 text-right">MP</th>
              <th className="py-2.5 px-3 text-right">W</th>
              <th className="py-2.5 px-3 text-right">{selectedLeague === 'nba_east' ? '-' : 'D'}</th>
              <th className="py-2.5 px-3 text-right">L</th>
              <th className="py-2.5 px-3 text-right">GD</th>
              <th className="py-2.5 px-3 text-right font-bold text-white">PTS</th>
              <th className="py-2.5 pl-3 pr-2 text-center">Last 5</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {standings.map((row) => {
              const isUclZone = row.rank <= 4;

              return (
                <tr
                  key={row.code}
                  className="transition-colors hover:bg-slate-850/50 group"
                >
                  {/* Rank with qualification indicator */}
                  <td className="py-3 pl-2 pr-3 tabular-nums font-bold text-slate-300">
                    <span className="flex items-center gap-1.5">
                      {isUclZone && (
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" title="Qualification Zone" />
                      )}
                      <span>{row.rank}</span>
                    </span>
                  </td>

                  {/* Team Name */}
                  <td className="py-3 px-3 font-sans font-medium text-slate-100 flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded bg-slate-800 text-[10px] font-bold text-white">
                      {row.code.slice(0, 2)}
                    </span>
                    <span className="truncate max-w-[150px] sm:max-w-none group-hover:text-emerald-400 transition-colors">
                      {row.team}
                    </span>
                  </td>

                  {/* Stats */}
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">{row.played}</td>
                  <td className="py-3 px-3 text-right tabular-nums text-emerald-400 font-semibold">{row.won}</td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-400">{row.drawn}</td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-400">{row.lost}</td>
                  <td className="py-3 px-3 text-right tabular-nums text-slate-300">
                    {row.goalDiff > 0 ? `+${row.goalDiff}` : row.goalDiff}
                  </td>
                  <td className="py-3 px-3 text-right tabular-nums font-bold text-emerald-400 text-sm">
                    {row.points}
                  </td>

                  {/* Form guide */}
                  <td className="py-3 pl-3 pr-2">
                    <div className="flex items-center justify-center gap-1">
                      {row.form.map((res, i) => (
                        <span
                          key={i}
                          className={`flex h-4 w-4 items-center justify-center rounded text-[9px] font-bold ${
                            res === 'W'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : res === 'D'
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-rose-500/20 text-rose-400'
                          }`}
                        >
                          {res}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-2.5">
        <span className="flex items-center gap-1">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          <span>Top 4 qualifies for Champions League / Playoffs</span>
        </span>
        <span className="text-slate-400 font-mono">Updated 10m ago</span>
      </div>
    </div>
  );
};
