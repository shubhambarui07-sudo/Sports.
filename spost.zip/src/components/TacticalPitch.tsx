import React, { useState } from 'react';
import { PlayerLineup } from '../types/sports';
import { Activity, Shield, Crosshair, Users } from 'lucide-react';

interface TacticalPitchProps {
  homeLineup: PlayerLineup[];
  awayLineup: PlayerLineup[];
  homeColor: string;
  awayColor: string;
  homeName: string;
  awayName: string;
}

export const TacticalPitch: React.FC<TacticalPitchProps> = ({
  homeLineup,
  awayLineup,
  homeColor,
  awayColor,
  homeName,
  awayName,
}) => {
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerLineup | null>(
    homeLineup.length > 0 ? homeLineup[5] : null
  );
  const [viewMode, setViewMode] = useState<'formation' | 'momentum'>('formation');

  return (
    <div className="flex flex-col rounded-xl border border-slate-800 bg-slate-900/80 p-4">
      {/* Controls header */}
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-emerald-400" />
          <span className="font-semibold text-xs tracking-wide text-slate-200">
            Tactical Pitch Visualizer
          </span>
          <span className="text-xs text-slate-400">· Formation & Spatial Coverage</span>
        </div>

        <div className="flex items-center gap-1 rounded-lg bg-slate-950 p-1 text-xs">
          <button
            onClick={() => setViewMode('formation')}
            className={`flex items-center gap-1 rounded px-2.5 py-1 transition-all ${
              viewMode === 'formation'
                ? 'bg-slate-800 text-white font-medium shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="h-3 w-3" />
            <span>Lineups</span>
          </button>
          <button
            onClick={() => setViewMode('momentum')}
            className={`flex items-center gap-1 rounded px-2.5 py-1 transition-all ${
              viewMode === 'momentum'
                ? 'bg-slate-800 text-white font-medium shadow-xs'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Crosshair className="h-3 w-3" />
            <span>Attack Pressure</span>
          </button>
        </div>
      </div>

      {/* SVG Pitch Canvas */}
      <div className="relative w-full overflow-hidden rounded-lg border border-emerald-950/60 bg-gradient-to-b from-[#0f281e] via-[#0b2018] to-[#0a1c15] shadow-inner aspect-[16/10] sm:aspect-[2/1]">
        <svg
          viewBox="0 0 1000 600"
          className="h-full w-full select-none"
          preserveAspectRatio="xMidYMid meet"
        >
          {/* Pitch grass striping */}
          <defs>
            <pattern id="grassStripes" width="100" height="600" patternUnits="userSpaceOnUse">
              <rect x="0" y="0" width="50" height="600" fill="#0d241b" fillOpacity="0.4" />
              <rect x="50" y="0" width="50" height="600" fill="#091d15" fillOpacity="0.4" />
            </pattern>

            {/* Momentum Gradient */}
            <linearGradient id="pressureGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ef4444" stopOpacity="0.1" />
              <stop offset="50%" stopColor="#10b981" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.1" />
            </linearGradient>
          </defs>

          {/* Background fill */}
          <rect x="0" y="0" width="1000" height="600" fill="url(#grassStripes)" />

          {/* Momentum overlay if active */}
          {viewMode === 'momentum' && (
            <rect x="250" y="60" width="500" height="480" fill="url(#pressureGradient)" rx="20" />
          )}

          {/* Pitch Markings */}
          <g stroke="#ffffff" strokeOpacity="0.35" strokeWidth="2.5" fill="none">
            {/* Outer boundary */}
            <rect x="40" y="30" width="920" height="540" />

            {/* Halfway line */}
            <line x1="500" y1="30" x2="500" y2="570" />

            {/* Center circle */}
            <circle cx="500" cy="300" r="85" />
            <circle cx="500" cy="300" r="3.5" fill="#ffffff" fillOpacity="0.6" />

            {/* Left penalty box (Home) */}
            <rect x="40" y="145" width="150" height="310" />
            <rect x="40" y="215" width="55" height="170" />
            <circle cx="150" cy="300" r="3" fill="#ffffff" fillOpacity="0.6" />
            <path d="M 190 240 A 85 85 0 0 1 190 360" />

            {/* Right penalty box (Away) */}
            <rect x="810" y="145" width="150" height="310" />
            <rect x="905" y="215" width="55" height="170" />
            <circle cx="850" cy="300" r="3" fill="#ffffff" fillOpacity="0.6" />
            <path d="M 810 240 A 85 85 0 0 0 810 360" />

            {/* Corner arcs */}
            <path d="M 40 50 A 20 20 0 0 0 60 30" />
            <path d="M 40 550 A 20 20 0 0 1 60 570" />
            <path d="M 960 50 A 20 20 0 0 1 940 30" />
            <path d="M 960 550 A 20 20 0 0 0 940 570" />
          </g>

          {/* Direction of play arrows */}
          <g fill="#ffffff" fillOpacity="0.2" textAnchor="middle" className="text-[12px] font-semibold tracking-wider">
            <text x="250" y="588">{homeName.toUpperCase()} ATTACK ➔</text>
            <text x="750" y="588">⬅ {awayName.toUpperCase()} ATTACK</text>
          </g>

          {/* Home Team Players */}
          {homeLineup.map((player) => {
            const posX = 40 + (player.x / 100) * 920;
            const posY = 30 + (player.y / 100) * 540;
            const isChosen = selectedPlayer?.id === player.id;

            return (
              <g
                key={player.id}
                transform={`translate(${posX}, ${posY})`}
                onClick={() => setSelectedPlayer(player)}
                className="cursor-pointer transition-transform hover:scale-110"
              >
                {/* Glow ring if selected */}
                {isChosen && (
                  <circle r="22" fill="none" stroke="#10b981" strokeWidth="2.5" strokeDasharray="4 2" />
                )}

                {/* Player disc */}
                <circle
                  r="16"
                  fill={homeColor}
                  stroke="#ffffff"
                  strokeWidth={isChosen ? "2.5" : "1.5"}
                  className="filter drop-shadow-md"
                />

                {/* Number */}
                <text
                  textAnchor="middle"
                  dy="5"
                  fill="#ffffff"
                  fontSize="12"
                  fontWeight="bold"
                  fontFamily="sans-serif"
                >
                  {player.number}
                </text>

                {/* Name Label */}
                <text
                  textAnchor="middle"
                  y="28"
                  fill="#f8fafc"
                  fontSize="10"
                  fontWeight="600"
                  className="drop-shadow-sm select-none"
                >
                  {player.name}
                </text>

                {/* Rating badge */}
                <g transform="translate(10, -12)">
                  <rect
                    x="0"
                    y="0"
                    width="22"
                    height="13"
                    rx="3"
                    fill={player.rating >= 8.0 ? '#059669' : '#334155'}
                  />
                  <text
                    x="11"
                    y="10"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize="9"
                    fontWeight="bold"
                  >
                    {player.rating.toFixed(1)}
                  </text>
                </g>
              </g>
            );
          })}

          {/* Away Team Players */}
          {awayLineup.map((player) => {
            const posX = 40 + (player.x / 100) * 920;
            const posY = 30 + (player.y / 100) * 540;
            const isChosen = selectedPlayer?.id === player.id;

            return (
              <g
                key={player.id}
                transform={`translate(${posX}, ${posY})`}
                onClick={() => setSelectedPlayer(player)}
                className="cursor-pointer transition-transform hover:scale-110"
              >
                {/* Glow ring if selected */}
                {isChosen && (
                  <circle r="22" fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeDasharray="4 2" />
                )}

                {/* Player disc */}
                <circle
                  r="16"
                  fill={awayColor}
                  stroke="#ffffff"
                  strokeWidth={isChosen ? "2.5" : "1.5"}
                  className="filter drop-shadow-md"
                />

                {/* Number */}
                <text
                  textAnchor="middle"
                  dy="5"
                  fill="#ffffff"
                  fontSize="12"
                  fontWeight="bold"
                  fontFamily="sans-serif"
                >
                  {player.number}
                </text>

                {/* Name Label */}
                <text
                  textAnchor="middle"
                  y="28"
                  fill="#f8fafc"
                  fontSize="10"
                  fontWeight="600"
                  className="drop-shadow-sm select-none"
                >
                  {player.name}
                </text>

                {/* Rating badge */}
                <g transform="translate(10, -12)">
                  <rect
                    x="0"
                    y="0"
                    width="22"
                    height="13"
                    rx="3"
                    fill={player.rating >= 8.0 ? '#0284c7' : '#334155'}
                  />
                  <text
                    x="11"
                    y="10"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontSize="9"
                    fontWeight="bold"
                  >
                    {player.rating.toFixed(1)}
                  </text>
                </g>
              </g>
            );
          })}
        </svg>
      </div>

      {/* Selected Player Detail Card */}
      {selectedPlayer && (
        <div className="mt-3 flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950 p-2.5 text-xs">
          <div className="flex items-center gap-3">
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-slate-800 font-mono text-xs font-bold text-white">
              #{selectedPlayer.number}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-100">{selectedPlayer.name}</span>
                <span className="text-slate-400 font-mono">({selectedPlayer.position})</span>
                {selectedPlayer.isCaptain && (
                  <span className="text-[10px] font-bold text-amber-400">[C]</span>
                )}
              </div>
              <p className="text-[11px] text-slate-400">
                Key role in current tactical build-up & transition positioning
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">Match Rating</span>
              <span className="font-mono text-sm font-bold text-emerald-400">
                {selectedPlayer.rating.toFixed(1)} / 10
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
