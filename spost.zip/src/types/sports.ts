export type SportType = 'all' | 'football' | 'basketball' | 'tennis' | 'formula1' | 'cricket';

export type MatchStatus = 'LIVE' | 'FINISHED' | 'UPCOMING';

export interface MatchEvent {
  minute: number;
  type: 'goal' | 'yellow_card' | 'red_card' | 'substitution' | 'three_pointer' | 'pitstop' | 'break_point' | 'wicket';
  player: string;
  team: 'home' | 'away';
  detail?: string;
}

export interface PlayerLineup {
  id: string;
  number: number;
  name: string;
  position: string;
  rating: number;
  isCaptain?: boolean;
  x: number; // Pitch coordinate 0-100%
  y: number; // Pitch coordinate 0-100%
}

export interface Match {
  id: string;
  sport: SportType;
  league: string;
  homeTeam: {
    name: string;
    shortName: string;
    code: string;
    score: number | string;
    color: string;
    secondaryColor: string;
    logoLetter: string;
  };
  awayTeam: {
    name: string;
    shortName: string;
    code: string;
    score: number | string;
    color: string;
    secondaryColor: string;
    logoLetter: string;
  };
  status: MatchStatus;
  statusText: string; // e.g. "78'", "Q4 3:12", "FT", "20:00 GMT"
  venue: string;
  attendance?: string;
  referee?: string;
  stats: {
    possession: [number, number]; // [home, away] in %
    shots: [number, number];
    shotsOnTarget: [number, number];
    xG?: [number, number];
    fouls: [number, number];
    corners?: [number, number];
    passesCompleted?: [number, number];
  };
  events: MatchEvent[];
  homeLineup: PlayerLineup[];
  awayLineup: PlayerLineup[];
  summary: string;
}

export interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string[];
  sport: SportType;
  category: string;
  author: {
    name: string;
    role: string;
    avatarInitials: string;
  };
  publishedAt: string;
  readTime: string;
  isFeatured?: boolean;
  commentsCount: number;
  tags: string[];
}

export interface TeamStanding {
  rank: number;
  team: string;
  code: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  goalsFor: number;
  goalsAgainst: number;
  goalDiff: number;
  points: number;
  form: ('W' | 'D' | 'L')[];
}

export interface FanPredictionPoll {
  id: string;
  title: string;
  sport: SportType;
  matchContext: string;
  deadline: string;
  options: {
    id: string;
    label: string;
    votes: number;
  }[];
  userVotedId?: string;
  totalVotes: number;
}

export interface BroadcastChannel {
  id: string;
  title: string;
  league: string;
  commentators: string;
  listeners: number;
  duration: string;
  status: 'LIVE' | 'RECORDED';
}
